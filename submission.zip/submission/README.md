# How to run on Emulator

- Build a new flutter project
- Copy and past 'pubspec.yaml' and 'lib' folder into the new project
- Go to Debug -> Start without debugging



# How to run on android phone

- Install the apk



# File discription

- main.dart := the entry point
- MyHomePage.dart := the basement
- GPSTracker folder := contains all files required for building a GPSTracker page
- MusicPlayer folder := contains all files for building a MusicPlayer page
- PaceCalculator := contains all files for building a PaceCalculator page
- RunningLog := contains all files for building a RunningLog page